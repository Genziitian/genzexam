# Quiz LAB source update — 18 October 2026

This is a source update, not a built Android release or a complete backend install. Back up your existing files before applying the matching paths. No .env or billing credentials are included.

- Merge backend/ files into your existing Hostinger backend directory. Preserve .env, APP_KEY, credentials and vendor.
- Apply database/migrations/2026_10_17_000003_create_membership_transactions_table.php from the backend directory, then php artisan optimize:clear. Google RTDN migration 000001 is already installed in the documented server setup.
- Upload the four web JS/HTML files to the matching website root (not the backend API root).
- Merge mobile/ source paths into the Flutter project and build/install a new release. Do not upload mobile source into public_html.
- Set GOOGLE_PLAY_PRO_ANNUAL_BASE_PLAN_ID=annual and PRO_ANNUAL_PRICE_PAISE=99900 if yearly settings are not already configured. Existing monthly/trial/billing credentials remain necessary.
- Read docs/MEMBERSHIP_PLANS_TRANSACTIONS_UPDATE.md for features, provider actions and owner checks. No deployment, migration or purchase was executed by this source update.

Earlier ZIP files may omit this update. This archive contains only the listed current files; it assumes the existing Quiz LAB project and previously installed dependencies.
