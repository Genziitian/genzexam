# Quiz LAB corrected source update v6 — 18 October 2026

Includes Upload → Convert → Take test guide with shared Free/Pro allowance states and one upload action, hidden rules with 30-second collapse, compact web upload screen, monthly/yearly Pro, transaction history, a dedicated management screen with cancellation and billing dates (pause/resume removed), aligned terms/privacy/refund/deletion policies, receipt-style trial breakdown with linked terms, billing gate correction and animated success tick. The compact paywall footer places text left and checkout right. The free upload allowance is merged into Claim 1 free upload, with a filled Get Pro upsell and left-aligned rules toggle.

This contains source files, not an APK or a complete backend installation. Back up existing files and merge matching paths. No .env, private keys, vendor or generated app build is included.

1. Merge backend/ into the existing public_html/backend. Preserve .env, APP_KEY, private credentials and installed dependencies.
2. From that backend folder, run:
   php artisan migrate --path=database/migrations/2026_10_17_000003_create_membership_transactions_table.php --force
   php artisan optimize:clear
3. Merge the web JS/HTML files into the website root.
4. Merge mobile/ source into the Flutter project, including mobile/lib/widgets/success_tick.dart, then rebuild and install the app. Do not upload mobile source to public_html.
5. Enable subscription.paused and subscription.resumed on the existing Razorpay signed webhook in addition to the previously configured lifecycle events.
6. Read docs/MEMBERSHIP_PLANS_TRANSACTIONS_UPDATE.md for the safe billing configuration diagnostic command and required settings. Paid plans no longer require a trial-offer ID. Checkout still requires backend verification configuration.

The source/archive layout was checked. No server deployment, database migration, app build, device session, or live payment was executed. The backend regression test is included but unrun. Installing these files does not by itself validate billing credentials or Play permissions.
